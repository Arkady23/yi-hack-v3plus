#!/bin/sh

printf "Content-Type: text/html\r\n\r\n"
printf "\ttest\t%s" "ok"
sync
